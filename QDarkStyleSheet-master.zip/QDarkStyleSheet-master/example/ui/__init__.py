"""
This package contains the qt designer files and ui scripts.
"""